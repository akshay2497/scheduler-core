package com.scheduler.service.scheduler.repository.pojo;

public enum EventType {
	API_CALL,
	KAFKA,
	RABBITMQ;
}
