package com.scheduler.service.scheduler.repository.pojo;

public enum ScheduleStatus {
	PENDING,
	IN_PROGRESS,
	COMPLETED,
	FAILED;
}
